
const ENDPOINTS = {
    COURSE_UPDATE: 'courses/updateCourse?courseCode=',
    ALLCOURSES: "courses/",
  };
  
  export default ENDPOINTS;
  