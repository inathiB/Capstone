import React, { useEffect, useState } from 'react';
import CourseController from '../../../Controllers/CourseController';
import LoadingPage from '../MainPages/LoadingPage';

const ReviewApplicant = ({ applicant }) => {
  const [courses, setCourses] = useState([]);
  const [selectedCourses,setSelectedCourses] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadCourses = async () => {
      const courseController = new CourseController();
      const data = await courseController.loadCourses();
      setCourses(data);
    };

    loadCourses();
  }, []);

    const updateChanges = ()=>{
        setLoading(true);
        if(selectedCourses.length === 0){
            
            alert("Updated successfully!");
            return
        }
        else {
            const courseController = new CourseController();
            let countUpdates = 0;
            let course = null;
            selectedCourses.forEach((courseCode)=>{
                course = courseController.getCourse(courseCode);
                console.log(course+" COMPARE TO "+courseCode);
                //course.tutors.push(applicant);
                courseController.updateCourse(course).then(()=>{
                    countUpdates++;
                    setLoading(false);
                    alert("Updated successfully !\n"+countUpdates+" - updates made\n"+applicant+" added to course(s) "+courseCode);
                });
            });
            
            
        }
        }

    // Handle checkbox change
    const handleCheckboxChange = (courseCode) => {
        if (selectedCourses.includes(courseCode)) {
        // If the course is already in the selectedCourses, remove it
        setSelectedCourses(selectedCourses.filter((code) => code !== courseCode));
        } else {
        // If the course is not in selectedCourses, add it
        setSelectedCourses([...selectedCourses, courseCode]);
        }
    };
  return (
    <>
    <td className='selectableCourses'>
        {loading && <LoadingPage elementBeingLoaded={'updates'}/>}
      {courses.map((course) => (
        <div key={course.courseCode}>
          <input
            type='checkbox'
            onChange={() => handleCheckboxChange(course.courseCode)}
            checked={selectedCourses.includes(course.courseCode)}
          />
          {course.courseCode}
        </div>
      ))}
    </td>
    <td>
        <button className="approve" onClick={updateChanges}>Update</button>
    </td>
    </>
  );
};

export default ReviewApplicant;

