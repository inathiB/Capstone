import Course from "../Models/Class files/Course";
import BackendService from "../Service/BackendService";
import ENDPOINTS from "../Service/EndPoints";

export default class CourseController{
    constructor(){
        this.courses = [];
        this.backendService = new BackendService("http://196.47.228.182:8080/api/v1");
        this.loadCourses().then((coursess)=>{
            this.courses = coursess;
        });
    }

    async loadCourses(){
        // try {
        //     const backCourses = await this.backendService.get(ENDPOINTS.ALLCOURSES);
        //     console.log(backCourses);
        // } catch (error) {
        //     console.log(error);
        // }
        
        this.courses = [
            new Course("Computer Science 3","CSC3003S","July - November","2023","Jenete Amahle"),
            new Course("Machine Learning", "ML101", "September - December","2023","Maria Rodriguez"),
            new Course("Information Systems 2","INF2011S","June - October", "2023","John Smith")
          ];

        return this.courses;
    }

    async updateCourse(course){
        try {
            const backCourses = await this.backendService.put(ENDPOINTS.COURSE_UPDATE+course.courseCode, course);
            console.log(backCourses);
        } catch (error) {
            console.log(error);
        }
        const index = this.courses.findIndex((app) => app.courseCode === course.courseCode);
        if (index >= 0) {
            this.courses[index] = course;
            return true;
        } else {
            alert("Could not update Courses!");
            return false;
        }
    }

    async addCourse(course){
        // try {
        //     const backCourses = await this.backendService.post(ENDPOINTS.ALLCOURSES, course);
        //     console.log(backCourses);
        // } catch (error) {
        //     console.log(error);
        // }
        this.courses.push(course);
    }
    getCourse(courseCode){
        return this.courses.find((course)=> course.courseCode === courseCode);
    }
    removeCourse(courseCode){
        //Method to remove course
    }
}

