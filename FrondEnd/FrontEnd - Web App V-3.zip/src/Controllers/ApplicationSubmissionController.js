import ApplicationSubmission from '../Models/Class files/ApplicationSubmission';

class ApplicationSubmissionController {
    constructor() {
        this.submissions = [new ApplicationSubmission(
            "Kwame Nkrumah - KKN001",
            new Date("2023-09-15"),
            "Computer Science"
        ),
        new ApplicationSubmission(
            "Nelson Mandela - MAN001",
            new Date("2023-09-20"),
            "Chemistry"
        ),
        new ApplicationSubmission(
            "Wangari Maathai MAW002",
            new Date("2023-09-25"),
            "Physics"
        ),
        new ApplicationSubmission(
            "Chinua Achebe  ACC002",
            new Date("2023-09-30"),
            "Mathematics"
        ),
        new ApplicationSubmission(
            "Malala Yousafzai - YOU001",
            new Date("2023-10-05"),
            "Biology"
          ),
          new ApplicationSubmission(
            "Marie Curie - CUR001",
            new Date("2023-10-10"),
            "Chemical Engineering"
          ),
          new ApplicationSubmission(
            "Albert Einstein - EIN001",
            new Date("2023-10-15"),
            "Physics"
          ),
          new ApplicationSubmission(
            "Ada Lovelace - LOV001",
            new Date("2023-10-20"),
            "Computer Engineering"
          ),
          new ApplicationSubmission(
            "Nikola Tesla - TES001",
            new Date("2023-10-25"),
            "Electrical Engineering"
          ),
          new ApplicationSubmission(
            "Martha Graham - GRA001",
            new Date("2023-10-30"),
            "Dance"
          ),
          new ApplicationSubmission(
            "Pablo Picasso - PIC001",
            new Date("2023-11-05"),
            "Art History"
          ),
          new ApplicationSubmission(
            "Alan Turing - TUR001",
            new Date("2023-11-10"),
            "Computer Science"
          ),
          new ApplicationSubmission(
            "Marie Skłodowska Curie - CUR002",
            new Date("2023-11-15"),
            "Chemistry"
          ),
          new ApplicationSubmission(
            "Leonardo da Vinci - VIN001",
            new Date("2023-11-20"),
            "Engineering"
          ),
          new ApplicationSubmission(
            "Isaac Newton - NEW001",
            new Date("2023-11-25"),
            "Mathematics"
          ),
          new ApplicationSubmission(
            "Rosalind Franklin - FRA001",
            new Date("2023-12-01"),
            "Biochemistry"
          ),
          new ApplicationSubmission(
            "Frida Kahlo - KAH001",
            new Date("2023-12-05"),
            "Art"
          ),
          new ApplicationSubmission(
            "Stephen Hawking - HAW001",
            new Date("2023-12-10"),
            "Cosmology"
          ),
          new ApplicationSubmission(
            "Mae Jemison - JEM001",
            new Date("2023-12-15"),
            "Astronautics"
          ),
    ];
    }

    // Create a new application submission
    createSubmission(studentDetails, department) {
        const dateSubmitted = new Date();
        const submission = new ApplicationSubmission(studentDetails, dateSubmitted, department);
        this.submissions.push(submission);
        return submission;
    }

    // Get all application submissions
    getAllSubmissions() {
        return this.submissions;
    }
}

export default ApplicationSubmissionController;
