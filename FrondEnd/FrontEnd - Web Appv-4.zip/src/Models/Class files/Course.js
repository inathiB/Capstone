export default class Course {
  constructor(courseName, courseCode,duration,year,creator) {
      this._courseCode = courseCode;
      this._courseName = courseName;
      this._duration = duration || "";
      this._year = year || "";
      this._creator = creator || "";
      this._ta = null;
      this.tutors = [];
  }

  // Getters
  get courseCode() {
      return this._courseCode;
  }

  get courseName() {
      return this._courseName;
  }

  get duration() {
      return this._duration;
  }

  get year() {
      return this._year;
  }

  get creator() {
      return this._creator;
  }

  // Setters
  set courseCode(courseCode) {
      this._courseCode = courseCode;
  }

  set courseName(courseName) {
      this._courseName = courseName;
  }

  set duration(duration) {
      this._duration = duration;
  }

  set year(year) {
      this._year = year;
  }

  set creator(creator) {
      this._creator = creator;
  }


 

  addTutor(tutor) {
      this.tutors.push(tutor);
  }

  removeLecturer(lecturer) {
      const index = this.lecturers.indexOf(lecturer);
      if (index !== -1) {
          this.lecturers.splice(index, 1);
      }
  }

  removeTA(ta) {
      const index = this.tas.indexOf(ta);
      if (index !== -1) {
          this.tas.splice(index, 1);
      }
  }

  removeTutor(tutor) {
      const index = this.tutors.indexOf(tutor);
      if (index !== -1) {
          this.tutors.splice(index, 1);
      }
  }

  // Method to convert the class object to a plain object
  toJSONType() {
    return {
      courseCode: this._courseCode,
      courseName: this._courseName,
      duration: this._duration,
      year: this._year,
      creator: this._creator,
      ta: this.ta,
      lecturers: this.lecturers,
       tutors: this.tutors,
    };
  }
  // Static method to create a Course instance from a plain object
  static fromJSONType(courseData) {
    const {
      courseCode,
      courseName,
      duration,
      year,
      creator,
      lecturers,
      tas,
      tutors,
    } = courseData;

    const course = new Course(courseName, courseCode, duration, year, creator);

    // Add lecturers, tas, and tutors to the course instance
    course.lecturers = lecturers || [];
    course.tas = tas || [];
    course.tutors = tutors || [];

    return course;
  }
}
