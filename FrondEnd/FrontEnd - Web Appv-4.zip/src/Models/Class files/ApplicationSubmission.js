class ApplicationSubmission {
    constructor(name, studentNumber, email, phone, yearOfStudy, submissionDate, department) {
        this.name = name;
        this.studentNumber = studentNumber;
        this.email = email;
        this.phone = phone;
        this.yearOfStudy = yearOfStudy;
        this.dateSubmitted = submissionDate;
        this.department = department;
    }

    studentDetails(){
        return `
        ${this.name} - ${this.studentNumber}\n
        ${this.email}\n
        ${this.yearOfStudy}
    `;
    }

    // Generate a random alphanumeric ID
    generateRandomId() {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        const idLength = 10;
        let randomId = '';

        for (let i = 0; i < idLength; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            randomId += characters.charAt(randomIndex);
        }

        return randomId;
    }
}

export default ApplicationSubmission;
