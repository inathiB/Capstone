import User from './User'

export default class Tutor extends User{
    constructor(username, password, studentID, name, email, phone) {
      super(username, password, 'tutor');
      this.studentID = studentID;
      this.name = name;
      this.email = email;
      this.phone = phone;
    }

    toJSONType() {
      return {
        username: this.username,
        password: this.password,
        role: this.role,
        studentID: this.studentID,
        name: this.name,
        email: this.email,
        phone: this.phone
      };
    }
}
  
  