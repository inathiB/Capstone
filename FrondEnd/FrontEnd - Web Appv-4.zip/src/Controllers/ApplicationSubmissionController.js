import ApplicationSubmission from '../Models/Class files/ApplicationSubmission';

class ApplicationSubmissionController {
    constructor() {
        this.submissions = [
            new ApplicationSubmission(
                "Kwame Nkrumah",
                "KKN001",
                "kwamenkrumah@gmail.com",
                "07344534543",
                "2nd year",
                new Date("2023-09-15"),
                "Computer Science"
            ),
            new ApplicationSubmission(
                "Nelso Mandela",
                "MAN001",
                "nelsonmandela@gmail.com",
                "07892345678",
                "1st year",
                new Date("2023-09-20"),
                "Chemistry"
            ),
            // Add more submissions with the updated attributes here...
        ];
    }

    // Create a new application submission
    createSubmission(name, studentNumber, email, phone, yearOfStudy, department) {
        const dateSubmitted = new Date();
        const submission = new ApplicationSubmission(
            name,
            studentNumber,
            email,
            phone,
            yearOfStudy,
            dateSubmitted,
            department
        );
        this.submissions.push(submission);
        return submission;
    }

    // Get all application submissions
    getAllSubmissions() {
        return this.submissions;
    }
}

export default ApplicationSubmissionController;
