import Course from "../Models/Class files/Course";
import BackendService from "../Service/BackendService";
import ENDPOINTS from "../Service/EndPoints";

export default class CourseController{
    constructor(){
        this.courses = [];
        this.backendService = new BackendService("http://196.47.228.182:8080/api/v1");
        this.loadCourses().then((coursess)=>{
            this.courses = coursess;
        });
    }

    async loadCourses() {
        try {
          const backCourses = await this.backendService.get(ENDPOINTS.ALLCOURSES);
          //console.log(backCourses);
      
          backCourses.forEach((element) => {
            if (this.courses.every((course) => course.courseCode !== element.courseCode)) {
              this.courses.push(Course.fromJSONType(element));
            }
          });
        } catch (error) {
          console.log(error);
        }
      
        return this.courses;
      }
      

    async updateCourse(course){
        try {
            const backCourses = await this.backendService.put(ENDPOINTS.COURSE_UPDATE+course.courseCode, course.toJSONType());
            console.log(backCourses);
            
        } catch (error) {
            console.log(error);
        }
        const index = this.courses.findIndex((app) => app.courseCode === course.courseCode);
        if (index >= 0) {
            this.courses[index] = course;
            return true;
        } else {
            alert("Could not update Courses!");
            return false;
        }
    }

    async addCourse(course){
        try {
            const backCourses = await this.backendService.post(ENDPOINTS.ALLCOURSES, course);
            console.log(backCourses);
        } catch (error) {
            console.log(error);
        }
        this.courses.push(course);
    }
    async getCourse(courseCode){
    
        await this.loadCourses();
        return this.courses.find((course)=> course.courseCode === courseCode);
    }
    async removeCourse(courseCode){
        try {
            await this.backendService.delete(`courses/${courseCode}`);
            return true;
        } catch (error) {
            console.log(error);
            return false;
        }
        
    }
}

