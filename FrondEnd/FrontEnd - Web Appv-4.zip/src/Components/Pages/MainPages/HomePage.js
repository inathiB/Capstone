import React from 'react'
import CourseTabs from '../courses/CourseTabs'

const HomePage = () => {

  return (
    <div>
      <CourseTabs/>
    </div>
  )
}

export default HomePage
