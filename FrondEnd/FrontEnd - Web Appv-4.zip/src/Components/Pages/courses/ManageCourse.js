import React, { useState,useEffect } from 'react';
import './styling/manageCourse.css'
import CourseController from '../../../Controllers/CourseController';
import { useLocation } from 'react-router-dom';
import Course from '../../../Models/Class files/Course';
import LoadingPage from '../MainPages/LoadingPage';

const ManageCourse = () => {
  //Get course from url
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const courseNameParam = searchParams.get('courseName');
  const courseCodeParam = searchParams.get('courseCode');
  const courseController = new CourseController();

 // Define state variables and setter functions
 const [courseName, setCourseName] = useState('');
 const [courseCode, setCourseCode] = useState('');
 const [duration, setDuration] = useState('');
 const [year, setYear] = useState('');
 const [creator, setCreator] = useState('');
 const [tutors, setTutors] = useState([]);
 const [loading, setLoading] = useState(true);

 useEffect(() => {
   // Create a function to fetch the course data and update the state
   async function fetchCourseInfo() {
     try {
       const courseController = new CourseController();
       const course = await courseController.getCourse(courseCodeParam);

       // Update the state with the received course data
       setCourseName(course.courseName);
       setCourseCode(course.courseCode);
       setDuration(course.duration);
       setYear(course.year);
       setCreator(course.creator);
       setTutors(course.tutors);
       setLoading(false);
     } catch (error) {
       console.error(error);
       setLoading(false);
     }
   }

   // Call the function to fetch the course data when the component mounts
   fetchCourseInfo();
 }, [courseCodeParam]);

  const handleTutorChange = (e, index) => {
    const updatedTutors = [...tutors];
    updatedTutors[index] = e.target.value;
    setTutors(updatedTutors);
  };

  const handleAddTutor = () => {
    setTutors([...tutors, '']);
  };

  const handleRemoveTutor = (index) => {
    const updatedTutors = [...tutors];
    updatedTutors.splice(index, 1);
    setTutors(updatedTutors);
  };

  const handleUpdateCourse = async () => {
    setLoading(true);
    const course = await courseController.getCourse(courseCode);
    if(course){
      course.duration = duration;
      course.year = year;
      course.tutors = tutors;
      const updatedCourseStatus = await courseController.updateCourse(course);
      if (updatedCourseStatus === true) alert("Updated successfully!");
      else alert("Something went wrong :(");
  }else{
      const updatedCourseStatus = await courseController.updateCourse(new Course(courseName,courseCode,duration,year,creator));
      if (updatedCourseStatus === true) alert("Updated successfully!");
      else alert("Something went wrong :(");
  }
  setLoading(false);

  };
 const handleDeleteCourse = async ()=>{
    const deleted = await courseController.removeCourse(courseCode);
    if(deleted) alert("Course removed");
    else alert("Something went wrong");
 }
  return (
    <div className="manage-course">
      {loading && <LoadingPage elementBeingLoaded={'updates'}/>}
      <h2>Manage Course - {courseNameParam}</h2>
      <label>
        Course Name:
        <input
          type="text"
          value={courseName}
          disabled
        />
      </label>
      <label>
        Course Code:
        <input
          type="text"
          value={courseCode}
          disabled
        />
      </label>
      <label>
        Duration:
        <input
          type="text"
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
        />
      </label>
      <label>
        Year:
        <input
          type="text"
          value={year}
          onChange={(e) => setYear(e.target.value)}
        />
      </label>
      <label>
        Creator:
        <input
          type="text"
          value={creator}
          disabled
        />
      </label>
      <h3>Tutors/Participants:</h3>
      {tutors.map((tutor, index) => (
        <div key={index}>
          <input
            type="text"
            value={tutor.name}
            onChange={(e) => handleTutorChange(e, index)}
          />
          <button onClick={() => handleRemoveTutor(index)}>Remove</button>
        </div>
      ))}
      <button onClick={handleAddTutor} className='tutor-button'>Add Tutor</button>
      <button onClick={handleUpdateCourse} className='tutor-button'>Update Course</button>
      <button onClick={handleDeleteCourse} className='tutor-button'>Remove course</button>
    </div>
  );
};

export default ManageCourse;

