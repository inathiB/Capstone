import React from 'react'

const SignUp = () => {
  return (
    <div>
      Sign for tutorials
    </div>
  )
}

export default SignUp
