export default class Application {
  constructor(applicationId, details, department, dueDate, accessLink) {
      this.applicationId = applicationId;
      this.department = department; 
      this.dueDate = dueDate;
      this.accessLink = accessLink;
      this.details= details;
  }


  
}


 