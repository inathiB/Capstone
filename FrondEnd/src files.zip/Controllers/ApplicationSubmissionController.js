import ApplicationSubmission from '../Models/Class files/ApplicationSubmission';

class ApplicationSubmissionController {
    constructor() {
        this.submissions = [new ApplicationSubmission(
            "Kwame Nkrumah",
            new Date("2023-09-15"),
            "Computer Science"
        ),
        new ApplicationSubmission(
            "Nelson Mandela",
            new Date("2023-09-20"),
            "Chemistry"
        ),
        new ApplicationSubmission(
            "Wangari Maathai",
            new Date("2023-09-25"),
            "Physics"
        ),
        new ApplicationSubmission(
            "Chinua Achebe",
            new Date("2023-09-30"),
            "Mathematics"
        ),];
    }

    // Create a new application submission
    createSubmission(studentDetails, department) {
        const dateSubmitted = new Date();
        const submission = new ApplicationSubmission(studentDetails, dateSubmitted, department);
        this.submissions.push(submission);
        return submission;
    }

    // Get all application submissions
    getAllSubmissions() {
        return this.submissions;
    }
}

export default ApplicationSubmissionController;
