import User from "../Models/Class files/User";
import BackendService from "../Service/BackendService";
export default class UserController {
    constructor() {
        this.users = [];
        this.backendService = new BackendService("http://196.47.228.182:8080/api/v1");
    }

    async loadUsers() {
        // Load users from the local database
        const localUsers = [
            new User("JNTAMA001", "123", 'tutor'),
            new User("Admin", "123", 'admin'),
            new User("1234", "123", 'admin')
        ];
    
        // Load users from the backend
        try {
            const backendUsers = await this.getUsersFromBE();
            const usersFromBackend = backendUsers.map(User.fromJSONType);
            // Concatenate both local and backend users
            this.users = [...localUsers, ...usersFromBackend];
            
        } catch (error) {
            console.error("Error loading users:", error);
            // If there's an error loading from the backend, fall back to local users
            this.users = localUsers;
        }
    }
    

    getUsersInorder(order) {
        switch (order) {
            case 'ascending':
                return this.users.slice().sort((a, b) => a.username.localeCompare(b.username));
            case 'descending':
                return this.users.slice().sort((a, b) => b.username.localeCompare(a.username));
            default:
                return [...this.users];
        }
    }

    userExists(username) {
        return this.users.some(user => user.username === username);
    }

    findUser(username) {
        return this.users.find(user => user.username === username);
    }
    async registerUser(user) {
        try {
            const response = await this.backendService.post('registration',user);
            console.log(response);
            return 1;
        } catch (error) {
            const res = (error.response.data) === "Email already Registered";
            console.log(res);
            if(res) return 0;
            return -1;
        }
    }
    async loginUser(user) {
        try {
            const response = await this.backendService.post_login(user);
            console.log(response);
            return response;
        } catch (error) {
            console.log(error);
            return false;
        }
    }

    async promoteToTutor(studentId){
        try {
            const response = await this.backendService.put('users/promotetotutor',studentId);
            console.log(response);
            return true;
        } catch (error) {
            console.log(error);
            return false;
        }
    }
    async getUsersFromBE() {
        try {
            const response = await this.backendService.get('users');
            // console.log(response);
            return response;
        } catch (error) {
            console.log(error);
            return [];
        }
    }
    async updateUser(updatedUser) {
        
        try {
            // Send a PUT request to update the user information on the backend
            const response = await this.backendService.put('users/updateUser', updatedUser);
            // Update the user in the local data store (assuming you have a user with the same username)
            const index = this.users.findIndex(user => user.username === updatedUser.username);
            if (index !== -1) {
                this.users[index] = updatedUser;
            }
            console.log(response);
            console.log(updatedUser);
            return true;
        } catch (error) {
            // Handle any errors that occur during the update process
            console.error("Error updating user:", error);
            return false;
        }
    }
}
