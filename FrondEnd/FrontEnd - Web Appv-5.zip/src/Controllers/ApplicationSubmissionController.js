import ApplicationSubmission from '../Models/Class files/ApplicationSubmission';
import BackendService from '../Service/BackendService';

class ApplicationSubmissionController {
    constructor() {
        this.submissions = [
            new ApplicationSubmission(
                "Kwame Nkrumah",
                "KKN001",
                "kwamenkrumah@gmail.com",
                "07344534543",
                "2nd year",
                new Date("2023-09-15"),
                "Computer Science"
            ),
            new ApplicationSubmission(
                "Nelso Mandela",
                "MAN001",
                "nelsonmandela@gmail.com",
                "07892345678",
                "1st year",
                new Date("2023-09-20"),
                "Chemistry"
            ),
        ];
        this.backendService = new BackendService("http://196.47.228.182:8080/api/v1");
    }

    // Create a new application submission
    async createSubmission(name, studentNumber, email, yearOfStudy, department,courseHistory) {
        const dateSubmitted = new Date();
        const submission = new ApplicationSubmission(
            name,
            studentNumber,
            email,
            yearOfStudy,
            dateSubmitted,
            department,
            courseHistory
        );
        try {
            const response = await this.backendService.post('applicationsubmission',submission);
            console("posted submission "+response);
            this.submissions.push(submission);
            return true;
        } catch (error) {
            return false;
        }
        
    }

    // Get all application submissions
    async getAllSubmissions() {
        try {
            const response = await this.backendService.get('applicationsubmission');
            //console.log("got submission/s "+response);
            if(response){
                let tempSubmisions = [];
                response.forEach(submission=>{
                    tempSubmisions.push(ApplicationSubmission.fromJSONType(submission));
                })
                this.submissions = tempSubmisions;
                return this.submissions;
            }
        } catch (error) {
            console.log(error);
            return [];
        }
        return this.submissions;
    }
}

export default ApplicationSubmissionController;
