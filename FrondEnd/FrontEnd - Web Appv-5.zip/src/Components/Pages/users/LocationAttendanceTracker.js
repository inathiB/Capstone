import React, { useState, useEffect } from 'react';
import './styling/LocationAttendanceTracker.css'; 
const LocationAttendanceTracker = () => {
  const [userLocation, setUserLocation] = useState(null);
  const [attendanceStatus, setAttendanceStatus] = useState(''); // 'Present' or 'Absent'
  
  const locationRadiusInMeters = 100; // Adjust as needed
  const [isCheckedIn, setIsCheckedIn] = useState(false);

  useEffect(() => {
    
    // Request location permissions and update user's location
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userLat = position.coords.latitude;
          const userLng = position.coords.longitude;
          setUserLocation({ latitude: userLat, longitude: userLng });
        },
        (error) => {
          console.error('Error getting user location:', error);
        }
      );
    } else {
      console.log('Geolocation is not supported by this browser.');
    }
  }, []);

  useEffect(() => {
    const classLocation = { latitude: -33.9571515, longitude: 18.4641483 };
    // Calculate the distance between user and class location
    if (userLocation) {
      const distance = calculateDistance(userLocation, classLocation);
      if (distance <= locationRadiusInMeters) {
        setAttendanceStatus('Present');
      } else {
        setAttendanceStatus('Absent');
      }
    }
  }, [userLocation]);

  const calculateDistance = (pointA, pointB) => {
    // Calculate distance between two coordinates using Haversine formula or geolib library
    // Example using geolib:
    const geolib = require('geolib');
    return geolib.getDistance(pointA, pointB);
  };

  const handleCheckIn = () => {
    setIsCheckedIn(true);
  };

  return (
    <div className="attendance-tracker">
      <h2>Location Attendance Tracker</h2>
      {userLocation && (
        <p>
          Your current location: Latitude {userLocation.latitude}, Longitude {userLocation.longitude}
        </p>
      )}
      {isCheckedIn ? (
        <p className={`attendance-status ${attendanceStatus.toLowerCase()}`}>
          Attendance Status: {attendanceStatus}
        </p>
      ) : (
        <button className="check-in-button" onClick={handleCheckIn}>
          Check-In
        </button>
      )}
    </div>
  );
};

export default LocationAttendanceTracker;
